import { IsUUID, IsDateString, IsNumber, Min } from 'class-validator';

export class CreateBookingDto {
  @IsUUID()
  guestId: string;

  @IsUUID()
  propertyId: string;

  @IsDateString()
  check_in: string;

  @IsDateString()
  check_out: string;

  @IsNumber()
  @Min(0)
  total_price: number;
}
