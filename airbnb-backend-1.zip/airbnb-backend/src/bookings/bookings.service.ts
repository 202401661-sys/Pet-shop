import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Booking } from './entities/booking.entity.js';
import { CreateBookingDto } from './dto/create-booking.dto.js';
import { UpdateBookingDto } from './dto/update-booking.dto.js';

@Injectable()
export class BookingsService {
  constructor(
    @InjectRepository(Booking)
    private readonly bookingsRepository: Repository<Booking>,
  ) {}

  create(dto: CreateBookingDto) {
    const booking = this.bookingsRepository.create({
      guest: { id: dto.guestId } as any,
      property: { id: dto.propertyId } as any,
      check_in: dto.check_in,
      check_out: dto.check_out,
      total_price: dto.total_price,
    });
    return this.bookingsRepository.save(booking);
  }

  findAll() {
    return this.bookingsRepository.find({ relations: ['guest', 'property'] });
  }

  async findOne(id: string) {
    const booking = await this.bookingsRepository.findOne({
      where: { id },
      relations: ['guest', 'property'],
    });
    if (!booking) {
      throw new NotFoundException(`Booking ${id} not found`);
    }
    return booking;
  }

  async update(id: string, dto: UpdateBookingDto) {
    const booking = await this.findOne(id);
    Object.assign(booking, dto);
    return this.bookingsRepository.save(booking);
  }

  async remove(id: string) {
    const booking = await this.findOne(id);
    return this.bookingsRepository.remove(booking);
  }
}
