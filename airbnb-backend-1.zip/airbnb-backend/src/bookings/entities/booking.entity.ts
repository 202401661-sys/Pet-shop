import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity.js';
import { Property } from '../../properties/entities/property.entity.js';

@Entity('bookings')
export class Booking {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, (user) => user.bookings)
  guest: User;

  @ManyToOne(() => Property, (property) => property.bookings)
  property: Property;

  @Column({ type: 'date' })
  check_in: string;

  @Column({ type: 'date' })
  check_out: string;

  @Column('decimal', { precision: 10, scale: 2 })
  total_price: number;

  @Column({ default: 'pending' })
  status: string; // TODO: replace with a BookingStatus relation once that table is added

  @CreateDateColumn()
  created_at: Date;
}
