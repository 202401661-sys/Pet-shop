import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './users/users.module.js';
import { PropertiesModule } from './properties/properties.module.js';
import { BookingsModule } from './bookings/bookings.module.js';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: Number(process.env.DB_PORT) || 5432,
      username: process.env.DB_USERNAME || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres',
      database: process.env.DB_DATABASE || 'airbnb_clone',
      autoLoadEntities: true,
      synchronize: true, // dev only — use migrations in production
    }),
    UsersModule,
    PropertiesModule,
    BookingsModule,
    // TODO: add the remaining modules here as you build them —
    // LocationsModule, PaymentsModule, ReviewsModule, WishlistsModule,
    // MessagingModule, NotificationsModule
  ],
})
export class AppModule {}
