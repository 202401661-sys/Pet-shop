import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Property } from './entities/property.entity.js';
import { CreatePropertyDto } from './dto/create-property.dto.js';
import { UpdatePropertyDto } from './dto/update-property.dto.js';

@Injectable()
export class PropertiesService {
  constructor(
    @InjectRepository(Property)
    private readonly propertiesRepository: Repository<Property>,
  ) {}

  create(dto: CreatePropertyDto) {
    const property = this.propertiesRepository.create(dto);
    return this.propertiesRepository.save(property);
  }

  findAll() {
    return this.propertiesRepository.find();
  }

  async findOne(id: string) {
    const property = await this.propertiesRepository.findOne({ where: { id } });
    if (!property) {
      throw new NotFoundException(`Property ${id} not found`);
    }
    return property;
  }

  async update(id: string, dto: UpdatePropertyDto) {
    const property = await this.findOne(id);
    Object.assign(property, dto);
    return this.propertiesRepository.save(property);
  }

  async remove(id: string) {
    const property = await this.findOne(id);
    return this.propertiesRepository.remove(property);
  }
}
