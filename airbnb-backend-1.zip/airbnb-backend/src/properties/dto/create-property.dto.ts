import {
  IsString,
  IsNumber,
  IsOptional,
  Min,
} from 'class-validator';

export class CreatePropertyDto {
  @IsString()
  title: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsNumber()
  @Min(0)
  price_per_night: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  max_guests?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  bedrooms?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  bathrooms?: number;
}
