# Airbnb Backend (NestJS + TypeORM + PostgreSQL)

## Setup
```bash
npm install
cp .env.example .env   # edit DB credentials
npm run start:dev
```
API base URL: `http://localhost:3000/api`

## What's included
- `users`, `properties`, `bookings` — full CRUD modules (entity, DTOs, service, controller, module), same pattern as your Products module.
- `TypeOrmModule.forRoot` in `app.module.ts` connects to Postgres and `synchronize: true` auto-creates tables in dev (turn this off and use migrations once you touch real data).
- `src/database/data-source.ts` — used for generating/running migrations later.

## Next steps — add the remaining modules
Follow the exact same 6-file pattern (`entity`, `dto/create-*.dto.ts`, `dto/update-*.dto.ts`, `*.service.ts`, `*.controller.ts`, `*.module.ts`) for the rest of the ERD:

- **Locations**: `countries`, `cities`, `locations`
- **Properties support**: `property_types`, `property_images`, `amenities`, `property_amenities`, `property_rules`, `property_availability`
- **Bookings support**: `booking_guests`, `booking_statuses`, `cancellation_policies`
- **Payments**: `payments`, `payment_methods`, `refunds`
- **Reviews**: `reviews`, `review_replies`
- **Wishlists**: `wishlists`, `wishlist_properties`
- **Messaging**: `conversations`, `conversation_participants`, `messages`
- **Notifications**: `notifications`
- **Auth**: `roles`, `user_roles`, `user_profiles`, `refresh_tokens` (usually goes with an `AuthModule` + JWT strategy)

Then register each new module in `app.module.ts` imports, same as `UsersModule`, `PropertiesModule`, `BookingsModule`.
