const express = require('express');
const db = new (require('better-sqlite3'))('erp.db');
db.exec(`
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name, price REAL, stock INT);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, name, email, phone);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, customer_id INT, product_id INT, qty INT, total REAL, date DEFAULT CURRENT_TIMESTAMP);`);

const app = express().use(express.json(), express.static('public'));
const tables = { products: ['name', 'price', 'stock'], customers: ['name', 'email', 'phone'] };

for (const [t, f] of Object.entries(tables)) {
  app.get(`/api/${t}`, (_, r) => r.json(db.prepare(`SELECT * FROM ${t}`).all()));
  app.post(`/api/${t}`, (q, r) => r.json(db.prepare(`INSERT INTO ${t}(${f}) VALUES(${f.map(() => '?')})`).run(f.map(k => q.body[k]))));
  app.delete(`/api/${t}/:id`, (q, r) => r.json(db.prepare(`DELETE FROM ${t} WHERE id=?`).run(q.params.id)));
}

app.get('/api/orders', (_, r) => r.json(db.prepare('SELECT * FROM orders').all()));
app.post('/api/orders', (q, r) => {
  const { customer_id, product_id, qty } = q.body;
  const p = db.prepare('SELECT * FROM products WHERE id=?').get(product_id);
  if (!p || p.stock < qty) return r.status(400).json({ error: 'Not enough stock' });
  db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(qty, product_id);
  r.json(db.prepare('INSERT INTO orders(customer_id,product_id,qty,total) VALUES(?,?,?,?)').run(customer_id, product_id, qty, p.price * qty));
});

app.get('/api/dashboard', (_, r) => r.json(db.prepare(
  `SELECT (SELECT COUNT(*) FROM products) products, (SELECT COUNT(*) FROM customers) customers,
   (SELECT COUNT(*) FROM orders) orders, (SELECT COALESCE(SUM(total),0) FROM orders) revenue`).get()));

app.listen(3000, () => console.log('http://localhost:3000'));
