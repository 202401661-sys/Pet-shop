# Mini ERP
Node.js + Express + SQLite. Run: `npm install` then `npm start`, open http://localhost:3000
