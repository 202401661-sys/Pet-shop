import { useEffect, useMemo, useState } from "react";

const api = async (url, options) => {
  const res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Something went wrong.");
  return res.status === 204 ? null : res.json();
};

const FILTERS = ["All", "Active", "Done"];
const PRIORITIES = ["low", "normal", "high"];

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("normal");
  const [filter, setFilter] = useState("All");
  const [error, setError] = useState("");

  const now = new Date();
  const weekday = now.toLocaleDateString("en-US", { weekday: "long" });
  const month = now.toLocaleDateString("en-US", { month: "long", year: "numeric" });

  useEffect(() => {
    api("/api/tasks").then(setTasks).catch(() => setError("Can't reach the server. Start the API on port 3001."));
  }, []);

  const done = tasks.filter((t) => t.done).length;
  const percent = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  const visible = useMemo(
    () => tasks.filter((t) => (filter === "All" ? true : filter === "Done" ? t.done : !t.done)),
    [tasks, filter]
  );

  const addTask = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const task = await api("/api/tasks", { method: "POST", body: JSON.stringify({ title, priority }) });
      setTasks((t) => [...t, task]);
      setTitle("");
      setError("");
    } catch (err) { setError(err.message); }
  };

  const toggle = async (task) => {
    const updated = await api(`/api/tasks/${task.id}`, { method: "PATCH", body: JSON.stringify({ done: !task.done }) });
    setTasks((t) => t.map((x) => (x.id === task.id ? updated : x)));
  };

  const remove = async (id) => {
    await api(`/api/tasks/${id}`, { method: "DELETE" });
    setTasks((t) => t.filter((x) => x.id !== id));
  };

  const clearDone = async () => {
    await api("/api/tasks", { method: "DELETE" });
    setTasks((t) => t.filter((x) => !x.done));
  };

  return (
    <div className="shell">
      <aside className="side">
        <div className="day">{now.getDate()}</div>
        <div className="weekday">{weekday}</div>
        <div className="month">{month}</div>

        <div className="progress" aria-label={`${percent}% complete`}>
          <div className="bar"><i style={{ width: `${percent}%` }} /></div>
          <p>{done} of {tasks.length} done</p>
        </div>
      </aside>

      <main className="main">
        <form className="add" onSubmit={addTask}>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Add a task for today" aria-label="New task" />
          <select value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Priority">
            {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <button type="submit">Add</button>
        </form>
        {error && <p className="error" role="alert">{error}</p>}

        <div className="bar-row">
          <div className="tabs" role="tablist">
            {FILTERS.map((f) => (
              <button key={f} role="tab" aria-selected={filter === f} className={filter === f ? "on" : ""} onClick={() => setFilter(f)}>{f}</button>
            ))}
          </div>
          {done > 0 && <button className="link" onClick={clearDone}>Clear completed</button>}
        </div>

        {visible.length === 0 ? (
          <p className="empty">{tasks.length === 0 ? "No tasks yet. Type one above and press Add." : `No ${filter.toLowerCase()} tasks.`}</p>
        ) : (
          <ul>
            {visible.map((t) => (
              <li key={t.id} className={`${t.done ? "done" : ""} p-${t.priority || "normal"}`}>
                <label>
                  <input type="checkbox" checked={t.done} onChange={() => toggle(t)} />
                  <span>{t.title}</span>
                </label>
                <em>{t.priority || "normal"}</em>
                <button className="link" onClick={() => remove(t.id)} aria-label={`Delete ${t.title}`}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
