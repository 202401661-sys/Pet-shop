import express from "express";
import cors from "cors";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB = path.join(__dirname, "tasks.json");

const load = () => {
  try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return []; }
};
const save = (tasks) => fs.writeFileSync(DB, JSON.stringify(tasks, null, 2));

const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/tasks", (_req, res) => res.json(load()));

app.post("/api/tasks", (req, res) => {
  const title = String(req.body?.title ?? "").trim();
  if (!title) return res.status(400).json({ error: "Task title is required." });
  const priority = ["low", "normal", "high"].includes(req.body?.priority) ? req.body.priority : "normal";
  const task = { id: Date.now().toString(36), title, priority, done: false, createdAt: new Date().toISOString() };
  const tasks = load();
  tasks.push(task);
  save(tasks);
  res.status(201).json(task);
});

app.patch("/api/tasks/:id", (req, res) => {
  const tasks = load();
  const task = tasks.find((t) => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found." });
  if (typeof req.body.done === "boolean") task.done = req.body.done;
  if (typeof req.body.title === "string" && req.body.title.trim()) task.title = req.body.title.trim();
  save(tasks);
  res.json(task);
});

app.delete("/api/tasks", (_req, res) => {
  save(load().filter((t) => !t.done));
  res.status(204).end();
});

app.delete("/api/tasks/:id", (req, res) => {
  const tasks = load();
  const next = tasks.filter((t) => t.id !== req.params.id);
  if (next.length === tasks.length) return res.status(404).json({ error: "Task not found." });
  save(next);
  res.status(204).end();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
