# Personal Planner (To-Do List)

React (Vite) frontend on :5173 + Express backend on :3001 (tasks saved in server/tasks.json).

## Run
    npm run install:all
    npm run dev

Then open http://localhost:5173
